package truetest.PROD.common

import com.kms.katalon.core.testdata.TestData as TestData
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

public class searchWithInputField {
    
    private static def execute(String input_search13) {
        
        "Step 1: Click on input search13"
        
        WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_sitesearch_docs_universalsearch_tsp/input_search13'))
        
        "Step 2: Click on input search13"
        
        WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_sitesearch_docs_universalsearch_tsp/input_search13'))
        
        "Step 3: Click on input search13"
        
        WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_sitesearch_docs_universalsearch_tsp/input_search13'))
        
        "Step 4: Enter input value in input search13"
        
        WebUI.setText(findTestObject('AI-Generated/PROD/Page_sitesearch_docs_universalsearch_tsp/input_search13'), input_search13)
        
        "Step 5: Click on button search5"
        
        WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_sitesearch_docs_universalsearch_tsp/button_search5'))
    }
}

