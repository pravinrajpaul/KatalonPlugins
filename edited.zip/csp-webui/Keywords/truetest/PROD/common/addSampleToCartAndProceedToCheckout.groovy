package truetest.PROD.common

import com.kms.katalon.core.testdata.TestData as TestData
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

public class addSampleToCartAndProceedToCheckout {

	private static def execute(String input_quantity17) {

		"Step 1: Click on button addSampleToCart2"

		WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_product_part_details/button_addSampleToCart2'))

		"Step 2: Click on link checkout52 -> Navigate to page '/store/*/samples-cart'"

		WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_product_part_details/link_checkout52'))

		"Step 3: Click on input quantity16"

		WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_store_samples_cart/input_quantity16'))

		"Step 4: Enter input value in input quantity17"

		WebUI.setText(findTestObject('AI-Generated/PROD/Page_store_samples_cart/input_quantity16'), input_quantity17)

		"Step 5: Click on button checkout2"

		WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_store_samples_cart/button_checkout2'))
	}
}

