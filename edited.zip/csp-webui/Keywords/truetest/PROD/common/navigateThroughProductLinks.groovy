package truetest.PROD.common

import com.kms.katalon.core.testdata.TestData as TestData
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

public class navigateThroughProductLinks {

	private static def execute() {

		"Step 1: Click on link products5"

		WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_home/link_products5'))

		"Step 2: Click on link applications"

		WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_home/link_applications'))

		"Step 3: Click on link designDevelopment2"

		WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_home/link_designDevelopment2'))

		"Step 4: Click on link qualityReliability"

		WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_home/link_qualityReliability'))

		"Step 5: Click on link orderingResources2"

		WebUI.enhancedClick(findTestObject('AI-Generated/PROD/Page_home/link_orderingResources2'))
	}
}

