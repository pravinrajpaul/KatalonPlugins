import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import java.nio.channels.FileChannel
import java.nio.channels.FileLock
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.Matcher
import java.util.regex.Pattern

import static java.nio.file.StandardOpenOption.CREATE
import static java.nio.file.StandardOpenOption.READ
import static java.nio.file.StandardOpenOption.WRITE
import static java.nio.file.StandardOpenOption.TRUNCATE_EXISTING

import java.nio.ByteBuffer

import javax.xml.parsers.SAXParserFactory

import org.apache.poi.ss.usermodel.Row
import org.apache.poi.ss.usermodel.WorkbookFactory

import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.InternalData
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.reader.ExcelFactory
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW

import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import groovy.json.JsonSlurper
import groovy.xml.XmlParser
import groovy.xml.XmlSlurper
import groovy.xml.slurpersupport.GPathResult

import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile

import internal.GlobalVariable as GlobalVariable

import groovy.util.Eval

import com.kms.katalon.core.annotation.BeforeTestCase
import com.kms.katalon.core.annotation.BeforeTestSuite
import com.kms.katalon.core.annotation.AfterTestCase
import com.kms.katalon.core.annotation.AfterTestSuite
import com.kms.katalon.core.context.TestCaseContext
import com.kms.katalon.core.context.TestSuiteContext
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testdata.TestDataInfo
import com.kms.katalon.core.testdata.TestDataType


class TestListener {


	static final int MAX_LOCK_ATTEMPTS  = Integer.getInteger("PFR_LOCK_ATTEMPTS", 200)
	static final int LOCK_SLEEP_MS      = Integer.getInteger("PFR_LOCK_SLEEP_MS", 25)
	static final int IO_MAX_RETRIES     = Integer.getInteger("PFR_IO_RETRIES", 3)
	static final int IO_BACKOFF_MS_BASE = Integer.getInteger("PFR_IO_BACKOFF_MS", 200)
	static final boolean FAIL_ON_IO     = Boolean.getBoolean("PFR_FAIL_ON_IO")
	static final int IN_USE_WAIT_MS          = Integer.getInteger("PFR_IN_USE_WAIT_MS", 1500)   // total wait before skipping
	static final int IN_USE_RECHECK_INTERVAL = Integer.getInteger("PFR_IN_USE_RECHECK_MS", 150) // poll interval
	static final ConcurrentHashMap<String,String> CLAIMED_SIGNATURE_BY_TC = new ConcurrentHashMap<>()


	@BeforeTestCase
	def beforeTestCase(TestCaseContext context) {
		
		
		boolean enabled = false
		try {
			enabled = GlobalVariable.PARALLEL_DATA_ENABLED
			KeywordUtil.logInfo("Found global variable PARALLEL_DATA_ENABLED, value = $enabled")
		} catch (MissingPropertyException e) {
			KeywordUtil.logInfo("GlobalVariable.PARALLEL_DATA_ENABLED not defined")
		}
		
		KeywordUtil.logInfo("Enabled : " + enabled)
		
		if (!enabled) {
			KeywordUtil.logInfo("[PFR] Disabled → skipping listener for " + context.getTestCaseId())
			return
		}

		try {
			KeywordUtil.logInfo("[PFR] BeforeTestCase: " + context.getTestCaseId())

			// ---------------- Tunables ----------------
			final int IN_USE_WAIT_MS        = Integer.getInteger("PFR_IN_USE_WAIT_MS", 0)      // 0 => immediate skip if in use
			final int IN_USE_RECHECK_MS     = Integer.getInteger("PFR_IN_USE_RECHECK_MS", 150) // poll interval when waiting
			final int IN_USE_LOCK_ATTEMPTS  = Integer.getInteger("PFR_IN_USE_LOCK_ATTEMPTS", 40) // per poll cycle

			// ---------------- Load active profile (.glbl) into pvars ----------------
			String execProfile = RunConfiguration.getExecutionProfile()
			String rel = execProfile?.startsWith("Profiles/") ? execProfile : "Profiles/" + execProfile
			if (!rel.endsWith(".glbl")) rel += ".glbl"
			File glbl = new File(RunConfiguration.getProjectDir(), rel)

			Map<String,Object> pvars = [:]
			if (glbl.exists()) {
				def xml = new XmlSlurper(false,false).parse(glbl)
				xml.'**'.findAll{ it.name()=='GlobalVariableEntity' }.each { gv ->
					String n = gv.'**'.find{ it.name()=='name' }?.text()
					String v = gv.'**'.find{ it.name()=='initValue' }?.text()
					if (n) {
						String t = v?.trim() ?: ""
						if ((t.startsWith('"')&&t.endsWith('"'))||(t.startsWith("'")&&t.endsWith("'"))) t = t.substring(1, t.length()-1)
						pvars[n] = t
					}
				}
				KeywordUtil.logInfo("[PFR] Loaded " + pvars.size() + " Global Variable(s) from profile")
			} else {
				KeywordUtil.markWarning("[PFR] Profile file not found: " + glbl.absolutePath)
			}

			// ---------------- Resolve + parse PARALLEL_DATA_FILTERS ----------------
			String filtersText = String.valueOf(pvars.getOrDefault("PARALLEL_DATA_FILTERS","")).trim()
			for (int i=0;i<10;i++){
				def m = (filtersText =~ /GlobalVariable\.([A-Za-z_][A-Za-z0-9_]*)/)
				if (!m.find()) break
					String key = m.group(1)
				String rep = String.valueOf(pvars.getOrDefault(key,""))
				filtersText = filtersText.replaceAll(
						/GlobalVariable\.${java.util.regex.Pattern.quote(key)}/,
						java.util.regex.Matcher.quoteReplacement(rep)
						)
			}
			if (!filtersText) {
				KeywordUtil.logInfo("[PFR] No PARALLEL_DATA_FILTERS → skip iteration")
				context.skipThisTestCase(); return
			}

			Map<String,List<String>> filtersOrdered = new LinkedHashMap<>()
			try {
				Object parsed = filtersText.startsWith("{") ? new JsonSlurper().parseText(filtersText) : Eval.me(filtersText)
				if (parsed instanceof Map) {
					(parsed as Map).each { k,v ->
						String key = String.valueOf(k)
						List<String> vals = (v instanceof Collection) ? (v as Collection).collect{ String.valueOf(it).trim() }
						: (v != null ? [String.valueOf(v).trim()] : [])
						filtersOrdered.put(key, vals.findAll{ it })
					}
				}
			} catch (Throwable t) {
				KeywordUtil.markWarning("[PFR] Filters parse error → skip: " + t.message)
				context.skipThisTestCase(); return
			}
			if (filtersOrdered.isEmpty()) {
				KeywordUtil.logInfo("[PFR] Empty filters → skip"); context.skipThisTestCase(); return
			}
			filtersOrdered.each { k, v -> KeywordUtil.logInfo("[PFR] Filter: " + k + " -> " + v) }

			// ---------------- Build signature from declared filter keys using THIS iteration’s values ----------------
			Map<String,Object> itv = context.getTestCaseVariables() ?: [:]
			Map<String,String> itvCI = [:]; itv.each { k,v -> if (k!=null) itvCI[k.toLowerCase()] = (v==null? "" : v.toString().trim()) }

			List<String> keyOrder = new ArrayList<>(filtersOrdered.keySet()) // preserve declared order
			List<String> missing = []
			List<String> denied  = []

			// Validate presence and allow-list
			filtersOrdered.each { kOrig, allowedVals ->
				String val = itvCI[kOrig.toLowerCase()]
				if (!val) {
					missing << kOrig
				} else if (!allowedVals.isEmpty() && !allowedVals.contains(val)) {
					denied << (kOrig + "='" + val + "'")
				}
			}
			if (!missing.isEmpty() || !denied.isEmpty()){
				if (!missing.isEmpty()) KeywordUtil.markWarning("[PFR] Missing iteration value(s) for: " + missing + " → skip")
				if (!denied.isEmpty())  KeywordUtil.markWarning("[PFR] Value(s) not allowed: " + denied + " → skip")
				context.skipThisTestCase(); return
			}

			String signatureCore = keyOrder.collect { kOrig ->
				String v = itvCI[kOrig.toLowerCase()] ?: ""
				kOrig + "(" + v + ")"
			}.join(", ")

			// Optional namespace (RUN_NUMBER or overridden name)
			String numName = String.valueOf(pvars.getOrDefault("PFR_NUMBER_PARAM_NAME", "RUN_NUMBER"))
			String numVal  = String.valueOf(pvars.getOrDefault(numName, "")).trim()
			String signatureLine = (numVal ? "num="+numVal+" | " : "") + signatureCore
			KeywordUtil.logInfo("[PFR] Signature: " + signatureLine)

			// ---------------- Registry path ----------------
			Path regPath = Paths.get(RunConfiguration.getProjectDir(), "Resources", "Dynamic Collection", "Data Status")
			try {
				Files.createDirectories(regPath.getParent())
			} catch (Throwable t) {
				KeywordUtil.markWarning("[PFR] Could not create parent dir: " + regPath.getParent() + " :: " + t.message)
			}
			if (Files.isDirectory(regPath)) {
				KeywordUtil.markWarning("[PFR] Registry path is a directory → skip")
				context.skipThisTestCase(); return
			}

			// ---------------- Main acquire/check/append loop with optional wait-if-in-use ----------------
			long deadline = System.currentTimeMillis() + Math.max(0, IN_USE_WAIT_MS)

			while (true) {
				// acquire registry lock with retries (short), then read
				FileChannel ch = null
				FileLock lk = null
				int lockAttempts = 0
				while (lk == null && lockAttempts < MAX_LOCK_ATTEMPTS) {
					try {
						ch = FileChannel.open(regPath, CREATE, READ, WRITE); lk = ch.tryLock()
					} catch (Throwable e) {
						lk = null
					}
					if (lk == null) {
						if (lockAttempts % 20 == 0) KeywordUtil.logInfo("[PFR] Waiting for registry lock ("+lockAttempts+"/"+MAX_LOCK_ATTEMPTS+")")
						Thread.sleep(LOCK_SLEEP_MS)
						lockAttempts++
						try {
							ch?.close()
						} catch (ignore) {}
					}
				}
				if (lk == null) {
					// couldn't get lock now; if we have time left (IN_USE_WAIT_MS>0), re-try; else skip
					if (System.currentTimeMillis() >= deadline) {
						KeywordUtil.markWarning("[PFR] Could not acquire registry lock → skip")
						context.skipThisTestCase(); return
					}
					Thread.sleep(IN_USE_RECHECK_MS)
					continue
				}

				boolean exists = false
				try {
					String content = ""
					long size = ch.size()
					if (size > 0) {
						ch.position(0L)
						ByteBuffer buf = ByteBuffer.allocate((int)Math.min(size, Integer.MAX_VALUE))
						int nTot=0; while (nTot<buf.capacity()) {
							int n=ch.read(buf); if(n<0) break; nTot+=n
						}
						buf.flip()
						content = new String(buf.array(), 0, buf.limit(), StandardCharsets.UTF_8)
					}
					exists = content?.split("\\R")?.any{ it == signatureLine } ?: false

					if (!exists) {
						// append & record claim, then done
						ch.position(ch.size())
						ch.write(ByteBuffer.wrap((signatureLine + System.lineSeparator()).getBytes(StandardCharsets.UTF_8)))
						ch.force(true)
						KeywordUtil.logInfo("[PFR] Claimed: " + signatureLine)
						// remember for @AfterTestCase removal
						CLAIMED_SIGNATURE_BY_TC.put(context.getTestCaseId(), signatureLine)
						return
					}
				} finally {
					// Always release lock before either waiting or skipping
					try {
						lk?.release()
					} catch (ignore) {}
					try {
						ch?.close()
					} catch (ignore) {}
				}

				// Signature exists: either skip immediately or wait/retry until deadline
				if (IN_USE_WAIT_MS <= 0 || System.currentTimeMillis() >= deadline) {
					KeywordUtil.markWarning("[PFR] Already in use → skip: " + signatureLine)
					context.skipThisTestCase(); return
				}
				Thread.sleep(IN_USE_RECHECK_MS)
			}
		} catch (Throwable t) {
			// Fail-open: never block the collection from starting
			KeywordUtil.markWarning("[PFR] beforeTestCase error → bypass: " + t.getClass().getSimpleName() + " - " + t.getMessage())
		}
	}



	@AfterTestCase
	def afterTestCase(TestCaseContext context) {

		boolean enabled = GlobalVariable.hasProperty("PARALLEL_DATA_ENABLED") ? String.valueOf(GlobalVariable.PARALLEL_DATA_ENABLED) : false
		if (!enabled) {
			KeywordUtil.logInfo("[PFR] Disabled → skipping listener for " + context.getTestCaseId())
			return
		}

		try {
			String signatureLine = CLAIMED_SIGNATURE_BY_TC.remove(context.getTestCaseId())
			if (signatureLine == null) return

				Path regPath = Paths.get(RunConfiguration.getProjectDir(), "Resources", "Dynamic Collection", "Data Status")
			if (!Files.exists(regPath) || Files.isDirectory(regPath)) return

				FileChannel ch = null; FileLock lk = null
			int attempts = 0
			while (lk == null && attempts < MAX_LOCK_ATTEMPTS) {
				try {
					ch = FileChannel.open(regPath, CREATE, READ, WRITE)
					lk = ch.tryLock()
				} catch (Throwable e) {
					lk = null
				}
				if (lk == null) {
					Thread.sleep(LOCK_SLEEP_MS); attempts++; try {
						ch?.close()
					} catch (ignore) {}
				}
			}
			if (lk == null) {
				KeywordUtil.markWarning("[PFR] Could not lock Data Status to remove"); return
			}

			try {
				// read, filter, write back
				String content = ""
				long size = ch.size()
				if (size > 0) {
					ch.position(0L)
					ByteBuffer buf = ByteBuffer.allocate((int)Math.min(size, Integer.MAX_VALUE))
					int nTot=0; while (nTot < buf.capacity()) {
						int n = ch.read(buf); if (n < 0) break; nTot += n
					}
					buf.flip()
					content = new String(buf.array(), 0, buf.limit(), StandardCharsets.UTF_8)
				}
				List<String> kept = new ArrayList<>()
				if (content) for (String line : content.split("\\R")) {
					if (line != null && !line.equals(signatureLine)) kept.add(line)
				}

				byte[] out = (kept.join(System.lineSeparator()) + (kept.isEmpty() ? "" : System.lineSeparator())).getBytes(StandardCharsets.UTF_8)
				ch.truncate(0L); ch.position(0L); ch.write(ByteBuffer.wrap(out)); ch.force(true)
				KeywordUtil.logInfo("[PFR] Removed from Data Status: " + signatureLine)
			} finally {
				try {
					lk?.release()
				} catch (ignore) {}
				try {
					ch?.close()
				} catch (ignore) {}
			}
		} catch (Throwable t) {
			KeywordUtil.markWarning("[PFR] afterTestCase error: " + t.getMessage())
		}
	}
}