
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String



def static "DataBindingDistributor.prepareCollectionDataSplit"(
    	String collectionPath	
     , 	String dataFile	) {
    (new DataBindingDistributor()).prepareCollectionDataSplit(
        	collectionPath
         , 	dataFile)
}
