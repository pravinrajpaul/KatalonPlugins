package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object url
     
    /**
     * <p></p>
     */
    public static Object TimeOut
     
    /**
     * <p></p>
     */
    public static Object testenv
     
    /**
     * <p></p>
     */
    public static Object ENV_NAME
     
    /**
     * <p></p>
     */
    public static Object USER_LIST
     
    /**
     * <p></p>
     */
    public static Object PARALLEL_DATA_FILTERS
     
    /**
     * <p></p>
     */
    public static Object PARALLEL_DATA_ENABLED
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
    
            url = selectedVariables['url']
            TimeOut = selectedVariables['TimeOut']
            testenv = selectedVariables['testenv']
            ENV_NAME = selectedVariables['ENV_NAME']
            USER_LIST = selectedVariables['USER_LIST']
            PARALLEL_DATA_FILTERS = selectedVariables['PARALLEL_DATA_FILTERS']
            PARALLEL_DATA_ENABLED = selectedVariables['PARALLEL_DATA_ENABLED']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
