import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.util.regex.Matcher

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import groovy.json.JsonSlurper
import groovy.xml.XmlParser
import groovy.xml.XmlSlurper
import groovy.xml.XmlUtil
import internal.GlobalVariable

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.testdata.TestDataFactory as TDF

class DataBindingDistributor {


	static class RunConfigInfo {
		String suiteRel         // e.g., "Test Suites/MobileCheck"
		String suiteName        // e.g., "MobileCheck"
		boolean runEnabled
		String profileName
		String runConfigurationId
		String groupName
		boolean suiteExists
		String collectionName
		String collectionPath
		String resolvedFilterRaw        // from profile GV (raw)
		String resolvedFilterEvaluated  // after resolving GlobalVariables
		Set<String> dataFileIds = [] as Set
		Integer idxInCollection         // order
	}

	@Keyword
	static void prepareCollectionDataSplit(String collectionPath, String dataFile) {
		final String projectDir = RunConfiguration.getProjectDir()
		final File   tscFile    = resolve(projectDir, collectionPath, ".ts")

		deleteDynamicCollectionFile(projectDir)
		createOrOverwriteDynamicCollectionFile(projectDir, "")

		List<RunConfigInfo> tsInfo = parseCollection(projectDir, tscFile)
		if (tsInfo == null || tsInfo.isEmpty()) {
			println ">>> No run-configs parsed."
			return
		}

		int collectionType = suiteChecks(tsInfo)

		if (collectionType <= 0) return

			def nCp = handleCollectionScenario(collectionType, tsInfo, projectDir, dataFile, collectionPath)

		if (nCp.equals("")||nCp.equals("Error")) return

			createOrOverwriteDynamicCollectionFile(projectDir, nCp)
	}

	// ---------- core parsing ----------

	private static List<RunConfigInfo> parseCollection(String projectDir, File tscFile) {
		if (!tscFile.exists()) {
			println "[INSPECT] Collection not found: ${tscFile.absolutePath}"
			return []
		}

		def tsc = new XmlSlurper(false, false).parse(tscFile)

		String colName   = textOf(tsc, 'name')
		String execMode  = textOf(tsc, 'executionMode')
		String maxCI     = textOf(tsc, 'maxConcurrentInstances')
		String delay     = textOf(tsc, 'delayBetweenInstances')

		println "==== TSC ===="
		println "Name: ${colName}"
		println "Path: ${rel(projectDir, tscFile)}"
		println "Mode: ${execMode} | MaxConcurrent: ${maxCI} | DelayBetweenInstances: ${delay}"
		println "=============="

		def runConfs = tsc.'**'.findAll { it.name() == 'TestSuiteRunConfiguration' }
		if (!runConfs) {
			println "[INSPECT] No TestSuiteRunConfiguration entries."
			return []
		}

		List<RunConfigInfo> out = []
		int idx = 0
		runConfs.each { rc ->
			idx++
			String suiteRel = textOf(rc, 'testSuiteEntity')
			String profile  = textOf(rc, 'profileName')
			if (!profile) profile = textOf(rc.'configuration', 'profileName')
			String runCfg   = textOf(rc, 'runConfigurationId')
			String group    = textOf(rc, 'groupName') ?: textOf(rc.'configuration', 'groupName')
			String runEn    = textOf(rc, 'runEnabled')
			boolean active  = (runEn == null) || !runEn.equalsIgnoreCase("false")

			File suiteFile = resolve(projectDir, suiteRel, ".ts")
			boolean suiteExists = suiteFile.exists()

			// profile -> Parallel_data_filters
			Map<String,Object> pvars = loadProfileVars(projectDir, profile)
			String rawFilter = String.valueOf(pvars.getOrDefault('Parallel_data_filters', '') ?: '').trim()
			String resolved  = resolvePlaceholders(rawFilter, pvars)

			Set<String> dfIds = [] as Set
			if (suiteExists) {
				def sxml = new XmlSlurper(false, false).parse(suiteFile)
				sxml.'**'.findAll { it.name() == 'testDataLink' }.each { tdl ->
					String df = String.valueOf(tdl.'**'.find { it.name() == 'testDataId' }?.text()).trim()
					if (df) dfIds << df
				}
			}

			RunConfigInfo info = new RunConfigInfo(
					suiteRel: suiteRel,
					suiteName: (suiteRel ? new File(suiteRel).name : ''),
					runEnabled: active,
					profileName: profile,
					runConfigurationId: runCfg,
					groupName: group,
					suiteExists: suiteExists,
					collectionName: colName,
					collectionPath: rel(projectDir, tscFile),
					resolvedFilterRaw: rawFilter,
					resolvedFilterEvaluated: resolved,
					dataFileIds: dfIds,
					idxInCollection: idx
					)
			out << info
		}

		return out
	}

	// ---------- suite checks (just prints per your rules) ----------

	private static int suiteChecks(List<RunConfigInfo> tsInfo) {
		// consider only active
		try {
			List<RunConfigInfo> active = tsInfo.findAll { it.runEnabled }

			// group by suite name (display name), as per your requirement
			Map<String, List<RunConfigInfo>> byName = active.groupBy { it.suiteName }

			// (a) all active suite names unique
			boolean allUnique = byName.values().every { it.size() == 1 }
			if (allUnique) {
				println ">> All unique active suites:"
				active.each { println "   - ${it.suiteName}  [profile=${it.profileName}]  (${it.suiteRel})" }
				return 1
			}

			// we have duplicates somewhere
			// split duplicate sets into: same profiles vs multiple profiles
			Map<String, List<RunConfigInfo>> duplicates = byName.findAll { k, v -> v.size() > 1 }


			List<String> multiProfileNames = duplicates.findAll { k, v ->
				v.collect { it.profileName }.toSet().size() > 1
			}.keySet() as List

			if (!multiProfileNames.isEmpty()) {
				println ">> Multiple suites with multiple profiles:"
				multiProfileNames.each { n ->
					def v = duplicates[n]
					Map<String, Integer> counts = v.groupBy { it.profileName }
					.collectEntries { pk, pv -> [(pk): pv.size()] }
					println "   - ${n}: " + counts.collect { k, c -> "${k} x${c}" }.join(", ")
				}
				return 3
			}

			// (b) duplicates but profiles are the same per name
			List<String> sameProfileNames = duplicates.findAll { k, v ->
				v.collect { it.profileName }.toSet().size() == 1
			}.keySet() as List

			if (!sameProfileNames.isEmpty()) {
				println ">> Multiple suites with matching profiles (duplicates share same profile):"
				sameProfileNames.each { n ->
					def v = duplicates[n]
					Map<String, Integer> counts = v.groupBy { it?.profileName ?: "(no profile)" }
					.collectEntries { pk, pv -> [(pk): (pv?.size() ?: 0)] }
					println "   - ${n}: " + counts.collect { k, c -> "${k} x${c}" }.join(", ")
				}

				// also list uniques alongside same-profile duplicates
				def uniqueEntries = byName.findAll { k, v -> v.size() == 1 }
				.collect { it.value[0] }
				if (!uniqueEntries.isEmpty()) {
					println ">> Unique active suites:"
					uniqueEntries.each { info ->
						def p = info?.profileName ?: "(no profile)"
						println "   - ${info.suiteName}: ${p}"
					}
				}
				return 2
			}

			// (c) duplicates with multiple profiles per name
		} catch (Throwable error) {

			println ">>> Some error occurred : " + error.getMessage()
			return -1
		}

		println ">>> Unidentified collection scenario"
		return 0
	}

	// ---------- helpers (unchanged from your version) ----------

	private static File resolve(String projectDir, String relPath, String ext) {
		String p = relPath.endsWith(ext) ? relPath : (relPath + ext)
		return new File(projectDir, p)
	}

	private static String rel(String projectDir, File f) {
		return f.absolutePath.replace(projectDir + File.separator, '')
	}

	private static String textOf(Object node, String tag) {
		def n = node.'**'.find { it.name() == tag }
		return n ? String.valueOf(n.text()).trim() : ""
	}

	private static Map<String, Object> loadProfileVars(String projectDir, String profileName) {
		Map<String, Object> m = [:]
		if (!profileName) return m
		File glbl = resolve(projectDir, "Profiles/${profileName}", ".glbl")
		if (!glbl.exists()) return m
		def x = new XmlSlurper(false, false).parse(glbl)
		x.'**'.findAll { it.name() == 'GlobalVariableEntity' }.each { gv ->
			String n = String.valueOf(gv.'**'.find { it.name() == 'name' }?.text())
			String v = String.valueOf(gv.'**'.find { it.name() == 'initValue' }?.text())
			if (n) m[n] = stripQuotes(v)
		}
		return m
	}

	private static String stripQuotes(String s) {
		if (s == null) return null
		String t = s.trim()
		if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) {
			return t.substring(1, t.length()-1)
		}
		return t
	}

	// Resolve nested GlobalVariable.X inside strings (guard 10)
	private static String resolvePlaceholders(String raw, Map<String, Object> pvars) {
		if (raw == null) return null
		String val = raw
		int guard = 0
		while (guard++ < 10) {
			def m = (val =~ /GlobalVariable\.([A-Za-z_][A-Za-z0-9_]*)/)
			if (!m.find()) break
				String key = m.group(1)
			String rep = String.valueOf(pvars.getOrDefault(key, ""))
			val = val.replaceAll(
					/GlobalVariable\.${java.util.regex.Pattern.quote(key)}/,
					Matcher.quoteReplacement(rep)
					)
		}
		return val
	}

	static String handleCollectionScenario(int branchCode, List<RunConfigInfo> tsInfo, String projectDir, String dataFile, String collectionPath) {
		try {
			switch (branchCode) {
				case 1:
				case 2:
					def nCp = updateSuitesWithFilters(tsInfo, projectDir, dataFile, collectionPath)
					return nCp
				case 3:
					def nCp = buildMultiProfileClonesAndPoint(projectDir, collectionPath, tsInfo)
					return nCp
				default:
					println ">>> Unknown branch code: ${branchCode}"
					return ""
			}
		}catch(Throwable error){
			println ">>> Some error occurred : "+ error.getMessage()
			return "Error"
		}
	}

	private static String updateSuitesWithFilters(List<RunConfigInfo> tsInfo, String projectDir, String dataFile, String collectionPath) {
		tsInfo.each { info ->
			def suitePath = info.suiteRel.endsWith(".ts") ? info.suiteRel : info.suiteRel + ".ts"
			File suiteFile = new File(projectDir, suitePath)

			if (!suiteFile.exists()) {
				println ">>> Suite not found: ${suitePath}"
				return
			}

			// Get row IDs from profile’s filters
			List<Integer> rowIds = resolveFilterRowIds(projectDir, info.profileName, dataFile, "PARALLEL_DATA_FILTERS")
			if (rowIds.isEmpty()) {
				println ">>> No matching rows for ${info.suiteName} (${info.profileName}) → skipping"
				return
			}

			// Update XML to SPECIFIC with row IDs
			String before = suiteFile.getText("UTF-8")
			String after  = forceSpecificRewrite(before, [(dataFile): rowIds])
			if (after != before) {
				suiteFile.setText(after, "UTF-8")
				println ">>> Updated ${info.suiteName} (${info.profileName}) with rows=${rowIds}"
			} else {
				println ">>> No changes for ${info.suiteName} (${info.profileName})"
			}
		}
		return collectionPath
	}


	private static String forceSpecificRewrite(String suiteXml, Map<String, List<Integer>> dfToRows) {
		if (!suiteXml || dfToRows == null || dfToRows.isEmpty()) return suiteXml

		def parser = new XmlParser(false, false)
		Node root
		try {
			root = parser.parseText(suiteXml)
		} catch (Throwable t) {

			return suiteXml
		}

		boolean changed = false
		root.'testCaseLink'.each { Node tcl ->
			tcl.'testDataLink'.each { Node tdl ->
				Node dfNode = (tdl.'testDataId' ? tdl.'testDataId'[0] : null) as Node
				if (!dfNode) return
					String dfId = String.valueOf(dfNode.text()).trim()
				List<Integer> rows = dfToRows[dfId]
				if (!rows || rows.isEmpty()) return

					// ensure/replace <iterationEntity>
					Node iterNode = (tdl.'iterationEntity' ? tdl.'iterationEntity'[0] : null) as Node
				if (iterNode == null) {
					iterNode = new Node(tdl, 'iterationEntity')
				} else {
					iterNode.children().clear()
				}
				new Node(iterNode, 'iterationType', 'SPECIFIC')
				new Node(iterNode, 'value', rows.join(','))

				changed = true
			}
		}

		return changed ? XmlUtil.serialize(root) : suiteXml
	}


	private static List<Integer> resolveFilterRowIds(String projectDir, String profileName, String dataFileId, String filterVarName) {

		if (!projectDir || projectDir.equals("")) projectDir = RunConfiguration.getProjectDir()
		String profRel = profileName ?: ""
		if (!profRel.startsWith("Profiles/")) profRel = "Profiles/" + profRel
		if (!profRel.endsWith(".glbl")) profRel = profRel + ".glbl"
		File glbl = new File(projectDir, profRel)

		Map<String,Object> pvars = [:]
		if (glbl.exists()) {
			def x = new XmlSlurper(false, false).parse(glbl)
			x.'**'.findAll { it.name() == 'GlobalVariableEntity' }.each { gv ->
				String n = String.valueOf(gv.'**'.find { it.name() == 'name' }?.text())
				String v = String.valueOf(gv.'**'.find { it.name() == 'initValue' }?.text())
				if (n) {
					String t = v == null ? "" : v.trim()
					if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) {
						t = t.substring(1, t.length()-1)
					}
					pvars[n] = t
				}
			}
		}

		// ---- 2) Fetch the filter string from the requested GV (default to Parallel_data_filters) ----
		String gvName = (filterVarName ?: "PARALLEL_DATA_FILTERS")
		String raw = String.valueOf(pvars.getOrDefault(gvName, ""))
		if (!raw) {
			println ">>> No filters found"
			return []
		}

		// ---- 3) Resolve nested GlobalVariable.* inside the filter string ----
		String resolved = raw
		int guard = 0
		while (guard++ < 10) {
			def m = (resolved =~ /GlobalVariable\.([A-Za-z_][A-Za-z0-9_]*)/)
			if (!m.find()) break
				String key = m.group(1)
			String rep = String.valueOf(pvars.getOrDefault(key, ""))
			resolved = resolved.replaceAll(
					/GlobalVariable\.${java.util.regex.Pattern.quote(key)}/,
					Matcher.quoteReplacement(rep)
					)
		}

		Map<String, List<String>> filters = [:]
		try {
			def obj
			if (resolved.trim().startsWith("{")) {
				obj = new JsonSlurper().parseText(resolved)
			} else {
				obj = Eval.me(resolved)
			}
			if (obj instanceof Map) {
				obj.each { k, v ->
					if (v instanceof Collection) {
						filters[(String)k] = v.collect { String.valueOf(it).trim() }
					} else if (v != null) {
						filters[(String)k] = [String.valueOf(v).trim()]
					}
				}
			}
		} catch (Throwable t) {
			println ">>> Error parsing filters: " + t.message
			return []
		}

		TestData td = null
		try {
			td = TestDataFactory.findTestData(dataFileId)
		} catch (Throwable ignored) {}
		if (td == null) {
			println ">>> Unable to load data file"
			return []
		}

		List<String> cols = td.getColumnNames()
		if (!filters.keySet().every { cols.contains(it) }) return []

		List<Integer> rows = []
		OUTER:
		for (int r = 1; r <= td.getRowNumbers(); r++) {
			for (String fk : filters.keySet()) {
				String cell = String.valueOf(td.getValue(fk, r))
				String norm = cell == null ? "" : cell.trim()
				if (!filters[fk].any { it != null && it.trim().equalsIgnoreCase(norm) }) {
					continue OUTER
				}
			}
			rows << r
		}

		return rows
	}

	private static void deleteDynamicCollectionFile(String projectDir) {
		File f = new File(projectDir, "Resources/Dynamic Collection/Collection")
		if (f.exists()) {
			if (f.delete()) {
				println "[DynamicCollection] Deleted: ${f.absolutePath}"
			} else {
				println "[DynamicCollection] Failed to delete: ${f.absolutePath}"
			}
		} else {
			println "[DynamicCollection] No Collection file to delete."
		}
	}

	private static void createOrOverwriteDynamicCollectionFile(String projectDir, String content) {
		File dir = new File(projectDir, "Resources/Dynamic Collection")
		if (!dir.exists()) {
			if (dir.mkdirs()) {
				println "[DynamicCollection] Created folder: ${dir.absolutePath}"
			} else {
				println "[DynamicCollection] Failed to create folder: ${dir.absolutePath}"
				return
			}
		}

		File f = new File(dir, "Collection")
		f.setText(content, "UTF-8")
		println "[Dynamic Collection] Collection file written: ${f.absolutePath} (size=${f.length()} bytes)"
	}

	private static void updateSuitesWithFilters(List<RunConfigInfo> tsInfo, String projectDir) {
		tsInfo.findAll { it?.runEnabled }.each { info ->
			String suiteRel = info.suiteRel?.endsWith(".ts") ? info.suiteRel : (info.suiteRel + ".ts")
			File suiteFile  = new File(projectDir, suiteRel)
			if (!suiteFile.exists()) {
				println "[UPD] Missing suite: ${suiteRel}"
				return
			}

			// 1) Collect DataFile IDs referenced in this suite
			Set<String> dfIds = [] as Set
			try {
				def sxml = new groovy.xml.XmlSlurper(false, false).parse(suiteFile)
				sxml.'**'.findAll { it.name() == 'testDataLink' }.each { tdl ->
					String df = String.valueOf(tdl.'**'.find { it.name() == 'testDataId' }?.text()).trim()
					if (df) dfIds << df
				}
			} catch (Throwable t) {
				println "[UPD] Parse error (${suiteRel}): ${t.message}"
				return
			}

			if (dfIds.isEmpty()) {
				println "[UPD] No DataFiles in ${suiteRel}"
				return
			}

			// 2) Compute SPECIFIC rows per DataFile using this profile’s filter
			Map<String, List<Integer>> dfToRows = [:]
			dfIds.each { String dfId ->
				List<Integer> rows = resolveFilterRowIds(projectDir,
						info.profileName ?: "",
						dfId,
						"PARALLEL_DATA_FILTERS")
				if (rows && !rows.isEmpty()) dfToRows[dfId] = rows
			}

			if (dfToRows.isEmpty()) {
				println "[UPD] No matching rows for ${info.suiteName} (profile=${info.profileName})"
				return
			}

			// 3) Patch suite XML to SPECIFIC with these rows
			String before = suiteFile.getText("UTF-8")
			String after  = forceSpecificRewrite(before, dfToRows)
			if (after != before) {
				suiteFile.setText(after, "UTF-8")
				println "[UPD] Patched ${info.suiteName} (profile=${info.profileName}) -> ${dfToRows}"
			} else {
				println "[UPD] No changes needed for ${info.suiteName} (profile=${info.profileName})"
			}
		}
	}

	// ===== BRANCH 3: Clone per (suite,profile), apply row filters, build new collection, write pointer =====
	private static String buildMultiProfileClonesAndPoint(String projectDir,
			String collectionPath,
			List<RunConfigInfo> tsInfo) {
		// Load original collection
		File tscFile = resolve(projectDir, collectionPath, ".ts")
		if (!tscFile.exists()) {
			println "[MP] Collection not found: ${tscFile.absolutePath}"; return
		}
		def tsc = new groovy.xml.XmlSlurper(false, false).parse(tscFile)
		String colName   = textOf(tsc, 'name') ?: stripExt(tscFile.name)
		String delay     = textOf(tsc, 'delayBetweenInstances') ?: "0"
		String execMode  = textOf(tsc, 'executionMode') ?: "PARALLEL"
		String maxCI     = textOf(tsc, 'maxConcurrentInstances') ?: "1"

		// Temp root: Test Suites/Temp_<CollectionName>[n]
		File tsRoot   = new File(projectDir, "Test Suites")
		File tempRoot = new File(tsRoot, "Temp_${colName}")
		int suffix = 1
		while (tempRoot.exists()) {
			tempRoot = new File(tsRoot, "Temp_${colName}${suffix++}")
		}
		if (!tempRoot.mkdirs()) {
			println "[MP] Failed to create: ${tempRoot.absolutePath}"; return
		}
		println "[MP] Temp root: ${tempRoot.absolutePath}"

		// Build cloned entries
		List<Map> entries = []
		Map<String,Integer> perSuiteCounter = [:]
		List<RunConfigInfo> active = tsInfo.findAll { it?.runEnabled }
		if (active.isEmpty()) {
			println "[MP] No active run-configs."; return
		}

		active.each { info ->
			// Source suite
			String suiteRel = info.suiteRel?.endsWith(".ts") ? info.suiteRel : (info.suiteRel + ".ts")
			File srcSuite   = new File(projectDir, suiteRel)
			if (!srcSuite.exists()) {
				entries << [cloneRel: suiteRel, profile: (info.profileName ?: ""),
					runCfg: (info.runConfigurationId ?: ""), group: (info.groupName ?: ""), runEnabled: false]
				println "[MP] Missing suite, disabling: ${suiteRel} (profile=${info.profileName})"
				return
			}

			// Collect DataFiles from suite
			Set<String> dfIds = [] as Set
			try {
				def sxml = new groovy.xml.XmlSlurper(false, false).parse(srcSuite)
				sxml.'**'.findAll { it.name() == 'testDataLink' }.each { tdl ->
					String df = String.valueOf(tdl.'**'.find { it.name() == 'testDataId' }?.text()).trim()
					if (df) dfIds << df
				}
			} catch (Throwable t) {
				println "[MP] Parse suite error (${suiteRel}): ${t.message}"
			}

			// Compute SPECIFIC rows per DataFile for this profile  <<< CALL IS HERE
			Map<String, List<Integer>> dfToRows = [:]
			dfIds.each { String dfId ->
				List<Integer> rows = resolveFilterRowIds(projectDir,
						info.profileName ?: "",
						dfId,
						"PARALLEL_DATA_FILTERS")
				if (rows && !rows.isEmpty()) dfToRows[dfId] = rows
			}
			boolean hasAnyRows = !dfToRows.isEmpty()

			// Create clone path: Temp_<col>/<SuiteName>/<SuiteName>__<ProfileSan>__<i>.ts
			String suiteName   = new File(suiteRel).name
			File suiteDir      = new File(tempRoot, suiteName); suiteDir.mkdirs()
			int i = ((perSuiteCounter[suiteName] ?: 0) + 1); perSuiteCounter[suiteName] = i
			String profileSan  = sanitize(info.profileName ?: "")
			String cloneName   = "${suiteName}__${profileSan}__${i}.ts"
			File cloneFile     = new File(suiteDir, cloneName)

			// Clone & patch rows (only if any)
			String originalXml = srcSuite.getText("UTF-8")
			String clonedXml   = hasAnyRows ? forceSpecificRewrite(originalXml, dfToRows) : originalXml
			cloneFile.setText(clonedXml, "UTF-8")
			println ">>> Cloned: ${cloneFile.absolutePath} (rows=" + (hasAnyRows ? dfToRows.values().flatten().size() : 0) + ")"

			// Add run-config entry for new collection
			String cloneRel = cloneFile.absolutePath.replace(projectDir + File.separator, "")
			entries << [
				cloneRel:   cloneRel,
				profile:    (info.profileName ?: ""),
				runCfg:     (info.runConfigurationId ?: ""),
				group:    info.groupName ?: "",
				runEnabled: hasAnyRows
			]
		}

		// Build and write the new collection XML inside temp root (same file name as original)
		String newTscXml = buildCollectionXml(colName, delay, execMode, maxCI, entries)
		File newTscFile  = new File(tempRoot, tscFile.name)
		newTscFile.setText(newTscXml, "UTF-8")
		println ">>> New collection: ${newTscFile.absolutePath}"
		return newTscFile.getAbsolutePath()
	}



	// Build collection XML from entries (clones), preserving exec settings
	private static String buildCollectionXml(String name,
			String delay,
			String execMode,
			String maxCI,
			List<Map> entries) {
		StringBuilder b = new StringBuilder()
		b.append('<?xml version="1.0" encoding="UTF-8"?>\n')
		b.append('<TestSuiteCollectionEntity>\n')
		b.append("   <description></description>\n")
		b.append("   <name>").append(name).append("</name>\n")
		b.append("   <tag></tag>\n")
		b.append("   <delayBetweenInstances>").append(delay).append("</delayBetweenInstances>\n")
		b.append("   <executionMode>").append(execMode).append("</executionMode>\n")
		b.append("   <maxConcurrentInstances>").append(maxCI).append("</maxConcurrentInstances>\n")
		b.append("   <testSuiteRunConfigurations>\n")

		entries.each { e ->
			b.append("      <TestSuiteRunConfiguration>\n")
			b.append("         <configuration>\n")
			b.append("            <groupName>").append(e.group ?: "Web Desktop").append("</groupName>\n")
			b.append("            <profileName>").append(e.profile).append("</profileName>\n")
			b.append("            <requireConfigurationData>false</requireConfigurationData>\n")
			b.append("            <runConfigurationId>").append(e.runCfg ?: "Chrome").append("</runConfigurationId>\n")
			b.append("         </configuration>\n")
			b.append("         <runEnabled>").append(e.runEnabled ? "true" : "false").append("</runEnabled>\n")
			b.append("         <testSuiteEntity>").append(e.cloneRel).append("</testSuiteEntity>\n")
			b.append("      </TestSuiteRunConfiguration>\n")
		}

		b.append("   </testSuiteRunConfigurations>\n")
		b.append("</TestSuiteCollectionEntity>\n")
		return b.toString()
	}

	// Write absolute path of the new collection into the pointer file (no extension)
	private static void writePointerPath(String projectDir, File targetTscFile) {
		File dynDir = new File(projectDir, "Resources/Dynamic Collection")
		if (!dynDir.exists()) dynDir.mkdirs()
		File pointer = new File(dynDir, "Collection")
		pointer.text = targetTscFile.getAbsolutePath()
	}

	// small helpers you likely already have
	private static String stripExt(String name) {
		int i = name.lastIndexOf('.')
		return i > 0 ? name.substring(0, i) : name
	}
	private static String sanitize(String s) {
		return (s ?: "").replaceAll('[^A-Za-z0-9_.-]', '_')
	}
}
