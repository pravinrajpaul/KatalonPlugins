param(
  [Parameter(Mandatory = $true)] [string]$ProjectPath,            # .prj file (with/without extension)
  [Parameter(Mandatory = $true)] [string]$KREPath,                # folder containing katalonc.exe
  [Parameter(Mandatory = $true)] [string]$DistributionSuitePath,  # e.g. Test Suites\DataDistributorSuite
  [string]$ExtraArgs = ""                                         # e.g. -apiKey=XXXX -orgId=... -testOpsProjectId=...
)

# ---------- Resolve paths ----------
$ProjectArg  = (Resolve-Path $ProjectPath).Path
$ProjectRoot = Split-Path -Parent $ProjectArg
$KREPath     = (Resolve-Path $KREPath).Path
$KatalonExe  = Join-Path $KREPath "katalonc.exe"

# Resources
$DataStatusPath = Join-Path $ProjectRoot "Resources\Dynamic Collection\Data Status"
$CollectionFile = Join-Path $ProjectRoot "Resources\Dynamic Collection\Collection"

# Internal settings files we’ll toggle
$AnalyticsFile = Join-Path $ProjectRoot "settings\internal\com.kms.katalon.integration.analytics.properties"
$ExecFile      = Join-Path $ProjectRoot "settings\internal\com.kms.katalon.execution.properties"

# ---------- Validate ----------
if (!(Test-Path $KatalonExe))     { Write-Error "katalonc not found at $KatalonExe"; exit 1 }


# ---------- Helpers ----------
$bakAnalytics = $null
$bakExec      = $null

function Backup-IfExists([string]$path, [ref]$store) {
  if (Test-Path $path) { $store.Value = Get-Content -LiteralPath $path -Raw }
}

function Set-Props([string]$path, [hashtable]$kv) {
  # ensure folder exists
  $dir = Split-Path -Parent $path
  if (!(Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }

  $lines = @()
  if (Test-Path $path) { $lines = (Get-Content -LiteralPath $path -Raw) -split "`r?`n" }

  foreach ($k in $kv.Keys) {
    $pattern = "^\s*$([Regex]::Escape($k))\s*="
    if ($lines -match $pattern) {
      $lines = $lines -replace "^\s*$([Regex]::Escape($k))\s*=\s*.*$", "$k=$($kv[$k])"
    } else {
      $lines += "$k=$($kv[$k])"
    }
  }
  ($lines -join "`r`n") | Set-Content -LiteralPath $path -Encoding UTF8
}

function Restore-File([string]$path, [string]$content) {
  if ($content -ne $null) {
    $content | Set-Content -LiteralPath $path -Encoding UTF8
  } elseif (Test-Path $path) {
    Remove-Item -LiteralPath $path -Force
  }
}

function Invoke-Katalon([string]$exe, [string]$argsLine) {
  Write-Host ">>> Executing: $exe $argsLine" -ForegroundColor Cyan
  $p = Start-Process -FilePath $exe -ArgumentList $argsLine -NoNewWindow -Wait -PassThru
  if ($p.ExitCode -ne 0) {
    Write-Error "Katalon run failed with exit code $($p.ExitCode)"
    exit $p.ExitCode
  }
}

# ---------- 1) Disable TestOps + emails for distributor run ----------
Backup-IfExists $AnalyticsFile ([ref]$bakAnalytics)
Backup-IfExists $ExecFile      ([ref]$bakExec)

# From your internal.zip:
# internal/com.kms.katalon.integration.analytics.properties
#   analytics.integration.enable=true
#   analytics.testreport.autoupload.enable=true
#   analytics.testcloud.integration.enable=true
# internal/com.kms.katalon.execution.properties
#   mailConfig.sendTestSuiteReport=true
#   mailConfig.sendTestSuiteCollectionReport=false
Set-Props $AnalyticsFile @{
  'analytics.integration.enable'            = 'false';
  'analytics.testreport.autoupload.enable'  = 'false';
  'analytics.testcloud.integration.enable'  = 'false'
}
Set-Props $ExecFile @{
  'mailConfig.sendTestSuiteReport'          = 'false';
  'mailConfig.sendTestSuiteCollectionReport'= 'false'
}
Write-Host "Temporarily disabled TestOps + email in project settings." -ForegroundColor Yellow

# ---------- Distributor run ----------
$distArgs = @(
  '-noSplash',
  '-runMode=console',
  "-projectPath=`"$ProjectArg`"",
  '-retry=0',
  "-testSuitePath=`"$DistributionSuitePath`"",
  $ExtraArgs
) -join ' '
Invoke-Katalon $KatalonExe $distArgs

# Cleanup registry file after distribution
if (Test-Path $DataStatusPath) {
  Remove-Item -LiteralPath $DataStatusPath -Force
  Write-Host "Deleted Data Status after distribution."
}

# ---------- 2) Restore settings BEFORE TSC run ----------
Restore-File $AnalyticsFile $bakAnalytics
Restore-File $ExecFile      $bakExec
Write-Host "Restored project TestOps/email settings." -ForegroundColor Yellow

# Read logical TSC path (first non-empty line)
if (!(Test-Path $CollectionFile)) { Write-Error "Collection file not found: $CollectionFile"; exit 1 }
$DistTSC = (Get-Content -LiteralPath $CollectionFile | Where-Object { $_.Trim() } | Select-Object -First 1).Trim()
if ([string]::IsNullOrWhiteSpace($DistTSC)) { Write-Error "Collection file is empty: $CollectionFile"; exit 1 }

# ---------- TSC run (normal) ----------
$tscArgs = @(
  '-noSplash',
  '-runMode=console',
  "-projectPath=`"$ProjectArg`"",
  '-retry=0',
  "-testSuiteCollectionPath=`"$DistTSC`"",
  $ExtraArgs
) -join ' '
Invoke-Katalon $KatalonExe $tscArgs

# Final cleanup
if (Test-Path $DataStatusPath) {
  Remove-Item -LiteralPath $DataStatusPath -Force
  Write-Host "Deleted Data Status after TSC."
}
