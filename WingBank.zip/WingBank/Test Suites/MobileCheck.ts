<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>MobileCheck</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>10</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>ff1cb57f-cdb6-4894-800c-19aac9978f23</testSuiteGuid>
   <testCaseLink>
      <guid>20604f2f-0645-4a73-9095-978b08c89c22</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mobile/Mobile TC1</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>4b3eea56-efa7-4c64-8d1a-2a6fb5f85c8b</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value>1,3</value>
         </iterationEntity>
         <testDataId>Data Files/ExcelData</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>4b3eea56-efa7-4c64-8d1a-2a6fb5f85c8b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>UserName</value>
         <variableId>92191726-94ac-4620-b158-269c62341699</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
